Dependencies:

'''pip install git+https://github.com/liboyue/Network-Distributed-Algorithm.git'''

If you have Nvidia GPUs, please also install `cupy`.
